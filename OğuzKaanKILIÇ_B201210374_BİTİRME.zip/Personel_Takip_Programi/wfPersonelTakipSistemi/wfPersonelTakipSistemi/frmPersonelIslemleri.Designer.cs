﻿namespace frmPersonelTakipSistemi
{
    partial class frmPersonelIslemleri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPersonelIslemleri));
            this.gbKisiBilgileri = new System.Windows.Forms.GroupBox();
            this.txtIstenCikis = new System.Windows.Forms.TextBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dtpIstenCikis = new System.Windows.Forms.DateTimePicker();
            this.cbDurum = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDepartman = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtAdres = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtTelefon = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSoyadi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAdi = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTCKN = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gbUcretBilgileri = new System.Windows.Forms.GroupBox();
            this.txtIseGiris = new System.Windows.Forms.TextBox();
            this.txtSabitMaas = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtIBAN = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.dtpIseGiris = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.btnYeni = new System.Windows.Forms.Button();
            this.btnDegistir = new System.Windows.Forms.Button();
            this.btnKaydet = new System.Windows.Forms.Button();
            this.btnSil = new System.Windows.Forms.Button();
            this.lvPersonel = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.txtByID = new System.Windows.Forms.TextBox();
            this.txtByTCKN = new System.Windows.Forms.TextBox();
            this.txtByAdi = new System.Windows.Forms.TextBox();
            this.txtBySoyadi = new System.Windows.Forms.TextBox();
            this.txtByTelefon = new System.Windows.Forms.TextBox();
            this.txtByAdres = new System.Windows.Forms.TextBox();
            this.txtByDepartman = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.gbKisiBilgileri.SuspendLayout();
            this.gbUcretBilgileri.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbKisiBilgileri
            // 
            this.gbKisiBilgileri.Controls.Add(this.txtIstenCikis);
            this.gbKisiBilgileri.Controls.Add(this.txtID);
            this.gbKisiBilgileri.Controls.Add(this.label5);
            this.gbKisiBilgileri.Controls.Add(this.dtpIstenCikis);
            this.gbKisiBilgileri.Controls.Add(this.cbDurum);
            this.gbKisiBilgileri.Controls.Add(this.label9);
            this.gbKisiBilgileri.Controls.Add(this.label6);
            this.gbKisiBilgileri.Controls.Add(this.txtDepartman);
            this.gbKisiBilgileri.Controls.Add(this.label7);
            this.gbKisiBilgileri.Controls.Add(this.txtAdres);
            this.gbKisiBilgileri.Controls.Add(this.label8);
            this.gbKisiBilgileri.Controls.Add(this.txtTelefon);
            this.gbKisiBilgileri.Controls.Add(this.label4);
            this.gbKisiBilgileri.Controls.Add(this.txtSoyadi);
            this.gbKisiBilgileri.Controls.Add(this.label3);
            this.gbKisiBilgileri.Controls.Add(this.txtAdi);
            this.gbKisiBilgileri.Controls.Add(this.label2);
            this.gbKisiBilgileri.Controls.Add(this.txtTCKN);
            this.gbKisiBilgileri.Controls.Add(this.label1);
            this.gbKisiBilgileri.Location = new System.Drawing.Point(72, 27);
            this.gbKisiBilgileri.Name = "gbKisiBilgileri";
            this.gbKisiBilgileri.Size = new System.Drawing.Size(213, 272);
            this.gbKisiBilgileri.TabIndex = 0;
            this.gbKisiBilgileri.TabStop = false;
            this.gbKisiBilgileri.Text = "Kişi Bilgileri";
            // 
            // txtIstenCikis
            // 
            this.txtIstenCikis.Location = new System.Drawing.Point(107, 243);
            this.txtIstenCikis.Name = "txtIstenCikis";
            this.txtIstenCikis.Size = new System.Drawing.Size(85, 20);
            this.txtIstenCikis.TabIndex = 26;
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(107, 31);
            this.txtID.Name = "txtID";
            this.txtID.ReadOnly = true;
            this.txtID.Size = new System.Drawing.Size(100, 20);
            this.txtID.TabIndex = 25;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 13);
            this.label5.TabIndex = 24;
            this.label5.Text = "Personel ID:";
            // 
            // dtpIstenCikis
            // 
            this.dtpIstenCikis.Location = new System.Drawing.Point(189, 243);
            this.dtpIstenCikis.Name = "dtpIstenCikis";
            this.dtpIstenCikis.Size = new System.Drawing.Size(18, 20);
            this.dtpIstenCikis.TabIndex = 23;
            this.dtpIstenCikis.ValueChanged += new System.EventHandler(this.dtpIstenCikis_ValueChanged);
            // 
            // cbDurum
            // 
            this.cbDurum.FormattingEnabled = true;
            this.cbDurum.Items.AddRange(new object[] {
            "Aktif",
            "Pasif"});
            this.cbDurum.Location = new System.Drawing.Point(107, 213);
            this.cbDurum.Name = "cbDurum";
            this.cbDurum.Size = new System.Drawing.Size(100, 21);
            this.cbDurum.TabIndex = 22;
            this.cbDurum.Text = "Aktif";
            this.cbDurum.SelectedIndexChanged += new System.EventHandler(this.cbDurum_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 246);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 13);
            this.label9.TabIndex = 20;
            this.label9.Text = "İşten Çıkış Tarihi:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 216);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Durum:";
            // 
            // txtDepartman
            // 
            this.txtDepartman.Location = new System.Drawing.Point(107, 187);
            this.txtDepartman.Name = "txtDepartman";
            this.txtDepartman.Size = new System.Drawing.Size(100, 20);
            this.txtDepartman.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 190);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Departman:";
            // 
            // txtAdres
            // 
            this.txtAdres.Location = new System.Drawing.Point(107, 161);
            this.txtAdres.Name = "txtAdres";
            this.txtAdres.Size = new System.Drawing.Size(100, 20);
            this.txtAdres.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 164);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "Adres:";
            // 
            // txtTelefon
            // 
            this.txtTelefon.Location = new System.Drawing.Point(107, 135);
            this.txtTelefon.Name = "txtTelefon";
            this.txtTelefon.Size = new System.Drawing.Size(100, 20);
            this.txtTelefon.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Telefon:";
            // 
            // txtSoyadi
            // 
            this.txtSoyadi.Location = new System.Drawing.Point(107, 109);
            this.txtSoyadi.Name = "txtSoyadi";
            this.txtSoyadi.Size = new System.Drawing.Size(100, 20);
            this.txtSoyadi.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Soyadı:";
            // 
            // txtAdi
            // 
            this.txtAdi.Location = new System.Drawing.Point(107, 83);
            this.txtAdi.Name = "txtAdi";
            this.txtAdi.Size = new System.Drawing.Size(100, 20);
            this.txtAdi.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Adı:";
            // 
            // txtTCKN
            // 
            this.txtTCKN.Location = new System.Drawing.Point(107, 57);
            this.txtTCKN.Name = "txtTCKN";
            this.txtTCKN.Size = new System.Drawing.Size(100, 20);
            this.txtTCKN.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tc Kimlik No:";
            // 
            // gbUcretBilgileri
            // 
            this.gbUcretBilgileri.Controls.Add(this.txtIseGiris);
            this.gbUcretBilgileri.Controls.Add(this.txtSabitMaas);
            this.gbUcretBilgileri.Controls.Add(this.label11);
            this.gbUcretBilgileri.Controls.Add(this.txtIBAN);
            this.gbUcretBilgileri.Controls.Add(this.label13);
            this.gbUcretBilgileri.Controls.Add(this.dtpIseGiris);
            this.gbUcretBilgileri.Controls.Add(this.label12);
            this.gbUcretBilgileri.Location = new System.Drawing.Point(381, 27);
            this.gbUcretBilgileri.Name = "gbUcretBilgileri";
            this.gbUcretBilgileri.Size = new System.Drawing.Size(233, 126);
            this.gbUcretBilgileri.TabIndex = 1;
            this.gbUcretBilgileri.TabStop = false;
            this.gbUcretBilgileri.Text = "Ücret Bilgileri";
            // 
            // txtIseGiris
            // 
            this.txtIseGiris.Location = new System.Drawing.Point(113, 34);
            this.txtIseGiris.Name = "txtIseGiris";
            this.txtIseGiris.Size = new System.Drawing.Size(87, 20);
            this.txtIseGiris.TabIndex = 26;
            // 
            // txtSabitMaas
            // 
            this.txtSabitMaas.Location = new System.Drawing.Point(113, 87);
            this.txtSabitMaas.Name = "txtSabitMaas";
            this.txtSabitMaas.Size = new System.Drawing.Size(101, 20);
            this.txtSabitMaas.TabIndex = 25;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(16, 87);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 13);
            this.label11.TabIndex = 24;
            this.label11.Text = "Sabit Maaş:";
            // 
            // txtIBAN
            // 
            this.txtIBAN.Location = new System.Drawing.Point(113, 60);
            this.txtIBAN.Name = "txtIBAN";
            this.txtIBAN.Size = new System.Drawing.Size(101, 20);
            this.txtIBAN.TabIndex = 23;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(16, 60);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 13);
            this.label13.TabIndex = 22;
            this.label13.Text = "IBAN:";
            // 
            // dtpIseGiris
            // 
            this.dtpIseGiris.Location = new System.Drawing.Point(197, 34);
            this.dtpIseGiris.Name = "dtpIseGiris";
            this.dtpIseGiris.Size = new System.Drawing.Size(17, 20);
            this.dtpIseGiris.TabIndex = 21;
            this.dtpIseGiris.ValueChanged += new System.EventHandler(this.dtpIseGiris_ValueChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(16, 34);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(76, 13);
            this.label12.TabIndex = 20;
            this.label12.Text = "İşe Giriş Tarihi:";
            // 
            // btnYeni
            // 
            this.btnYeni.Location = new System.Drawing.Point(381, 181);
            this.btnYeni.Name = "btnYeni";
            this.btnYeni.Size = new System.Drawing.Size(106, 51);
            this.btnYeni.TabIndex = 2;
            this.btnYeni.Text = "Yeni";
            this.btnYeni.UseVisualStyleBackColor = true;
            this.btnYeni.Click += new System.EventHandler(this.btnYeni_Click);
            // 
            // btnDegistir
            // 
            this.btnDegistir.Enabled = false;
            this.btnDegistir.Location = new System.Drawing.Point(508, 181);
            this.btnDegistir.Name = "btnDegistir";
            this.btnDegistir.Size = new System.Drawing.Size(106, 51);
            this.btnDegistir.TabIndex = 3;
            this.btnDegistir.Text = "Değiştir";
            this.btnDegistir.UseVisualStyleBackColor = true;
            this.btnDegistir.Click += new System.EventHandler(this.btnDegistir_Click);
            // 
            // btnKaydet
            // 
            this.btnKaydet.Enabled = false;
            this.btnKaydet.Location = new System.Drawing.Point(381, 248);
            this.btnKaydet.Name = "btnKaydet";
            this.btnKaydet.Size = new System.Drawing.Size(106, 51);
            this.btnKaydet.TabIndex = 4;
            this.btnKaydet.Text = "Kaydet";
            this.btnKaydet.UseVisualStyleBackColor = true;
            this.btnKaydet.Click += new System.EventHandler(this.btnKaydet_Click);
            // 
            // btnSil
            // 
            this.btnSil.Enabled = false;
            this.btnSil.Location = new System.Drawing.Point(508, 248);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(106, 51);
            this.btnSil.TabIndex = 5;
            this.btnSil.Text = "Sil";
            this.btnSil.UseVisualStyleBackColor = true;
            this.btnSil.Click += new System.EventHandler(this.btnSil_Click);
            // 
            // lvPersonel
            // 
            this.lvPersonel.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8});
            this.lvPersonel.FullRowSelect = true;
            this.lvPersonel.Location = new System.Drawing.Point(71, 376);
            this.lvPersonel.Name = "lvPersonel";
            this.lvPersonel.Size = new System.Drawing.Size(543, 183);
            this.lvPersonel.TabIndex = 6;
            this.lvPersonel.UseCompatibleStateImageBehavior = false;
            this.lvPersonel.View = System.Windows.Forms.View.Details;
            this.lvPersonel.SelectedIndexChanged += new System.EventHandler(this.lvPersonel_SelectedIndexChanged);
            this.lvPersonel.DoubleClick += new System.EventHandler(this.lvPersonel_DoubleClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "ID";
            this.columnHeader1.Width = 28;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "TCKN";
            this.columnHeader2.Width = 74;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Adı";
            this.columnHeader3.Width = 70;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Soyadı";
            this.columnHeader4.Width = 77;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Telefon";
            this.columnHeader5.Width = 63;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Adres";
            this.columnHeader6.Width = 78;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Departman";
            this.columnHeader7.Width = 73;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Durum";
            this.columnHeader8.Width = 75;
            // 
            // txtByID
            // 
            this.txtByID.Location = new System.Drawing.Point(71, 350);
            this.txtByID.Name = "txtByID";
            this.txtByID.Size = new System.Drawing.Size(28, 20);
            this.txtByID.TabIndex = 27;
            this.txtByID.TextChanged += new System.EventHandler(this.txtByID_TextChanged);
            // 
            // txtByTCKN
            // 
            this.txtByTCKN.Location = new System.Drawing.Point(102, 350);
            this.txtByTCKN.Name = "txtByTCKN";
            this.txtByTCKN.Size = new System.Drawing.Size(73, 20);
            this.txtByTCKN.TabIndex = 28;
            this.txtByTCKN.TextChanged += new System.EventHandler(this.txtByTCKN_TextChanged);
            // 
            // txtByAdi
            // 
            this.txtByAdi.Location = new System.Drawing.Point(179, 350);
            this.txtByAdi.Name = "txtByAdi";
            this.txtByAdi.Size = new System.Drawing.Size(71, 20);
            this.txtByAdi.TabIndex = 29;
            this.txtByAdi.TextChanged += new System.EventHandler(this.txtByAdi_TextChanged);
            // 
            // txtBySoyadi
            // 
            this.txtBySoyadi.Location = new System.Drawing.Point(254, 350);
            this.txtBySoyadi.Name = "txtBySoyadi";
            this.txtBySoyadi.Size = new System.Drawing.Size(69, 20);
            this.txtBySoyadi.TabIndex = 30;
            this.txtBySoyadi.TextChanged += new System.EventHandler(this.txtBySoyadi_TextChanged);
            // 
            // txtByTelefon
            // 
            this.txtByTelefon.Location = new System.Drawing.Point(327, 350);
            this.txtByTelefon.Name = "txtByTelefon";
            this.txtByTelefon.Size = new System.Drawing.Size(57, 20);
            this.txtByTelefon.TabIndex = 31;
            this.txtByTelefon.TextChanged += new System.EventHandler(this.txtByTelefon_TextChanged);
            // 
            // txtByAdres
            // 
            this.txtByAdres.Location = new System.Drawing.Point(387, 350);
            this.txtByAdres.Name = "txtByAdres";
            this.txtByAdres.Size = new System.Drawing.Size(74, 20);
            this.txtByAdres.TabIndex = 32;
            this.txtByAdres.TextChanged += new System.EventHandler(this.txtByAdres_TextChanged);
            // 
            // txtByDepartman
            // 
            this.txtByDepartman.Location = new System.Drawing.Point(464, 350);
            this.txtByDepartman.Name = "txtByDepartman";
            this.txtByDepartman.Size = new System.Drawing.Size(70, 20);
            this.txtByDepartman.TabIndex = 33;
            this.txtByDepartman.TextChanged += new System.EventHandler(this.txtByDepartman_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(72, 324);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(286, 13);
            this.label10.TabIndex = 34;
            this.label10.Text = "* Aşağıdaki arama kutuları ile filtreleme işlemini yapabilirsiniz.";
            // 
            // frmPersonelIslemleri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(712, 570);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtByDepartman);
            this.Controls.Add(this.txtByAdres);
            this.Controls.Add(this.txtByTelefon);
            this.Controls.Add(this.txtBySoyadi);
            this.Controls.Add(this.txtByAdi);
            this.Controls.Add(this.txtByTCKN);
            this.Controls.Add(this.txtByID);
            this.Controls.Add(this.lvPersonel);
            this.Controls.Add(this.btnSil);
            this.Controls.Add(this.btnKaydet);
            this.Controls.Add(this.btnDegistir);
            this.Controls.Add(this.btnYeni);
            this.Controls.Add(this.gbUcretBilgileri);
            this.Controls.Add(this.gbKisiBilgileri);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmPersonelIslemleri";
            this.Text = "PERSONEL İŞLEMLERİ";
            this.Load += new System.EventHandler(this.frmPersonelIslemleri_Load);
            this.gbKisiBilgileri.ResumeLayout(false);
            this.gbKisiBilgileri.PerformLayout();
            this.gbUcretBilgileri.ResumeLayout(false);
            this.gbUcretBilgileri.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbKisiBilgileri;
        private System.Windows.Forms.ComboBox cbDurum;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtDepartman;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtAdres;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtTelefon;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtSoyadi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAdi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTCKN;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gbUcretBilgileri;
        private System.Windows.Forms.TextBox txtSabitMaas;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtIBAN;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker dtpIseGiris;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnYeni;
        private System.Windows.Forms.Button btnDegistir;
        private System.Windows.Forms.Button btnKaydet;
        private System.Windows.Forms.Button btnSil;
        private System.Windows.Forms.ListView lvPersonel;
        private System.Windows.Forms.DateTimePicker dtpIstenCikis;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtIstenCikis;
        private System.Windows.Forms.TextBox txtIseGiris;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.TextBox txtByID;
        private System.Windows.Forms.TextBox txtByTCKN;
        private System.Windows.Forms.TextBox txtByAdi;
        private System.Windows.Forms.TextBox txtBySoyadi;
        private System.Windows.Forms.TextBox txtByTelefon;
        private System.Windows.Forms.TextBox txtByAdres;
        private System.Windows.Forms.TextBox txtByDepartman;
        private System.Windows.Forms.Label label10;
    }
}