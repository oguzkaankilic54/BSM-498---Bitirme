﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wfPersonelTakipSistemi
{
    public partial class wfPersonelIslemleri : Form
    {
        public wfPersonelIslemleri()
        {
            InitializeComponent();
        }

        private void gbUcretBilgileri_Enter(object sender, EventArgs e)
        {

        }
    }
}
